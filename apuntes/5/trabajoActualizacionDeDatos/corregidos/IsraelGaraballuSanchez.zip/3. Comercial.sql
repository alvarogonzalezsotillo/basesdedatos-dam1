-- Nos conectamos como COMERCIAL y usamos la sentencia SYNONYM
connect comercial/comercial;
create synonym oficinas for informatica.oficinas;
create synonym empleados for informatica.empleados;
create synonym clientes for informatica.clientes;
create synonym pedidos for informatica.pedidos;
create synonym detallepedidos for informatica.detallepedidos;
create synonym productos for informatica.productos;

commit;