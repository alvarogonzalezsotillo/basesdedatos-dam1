-- A�adimos a nuestra base de datos un nivel de aislamiento para que no haya problemas al modificar la misma fila varios usuarios a la vez
Set transaction isolation level Serializable;

-- Nos volvemos a conectar como COMERCIAL y miramos de cuantas ajedreas disponemos
connect comercial/comercial;
select cantidadenstock from productos
  where nombre='Ajedrea';

-- Eliminamos 50 ajedreas que son las que desea PepeGardens
update productos
  set cantidadenstock = 90
  where nombre='Ajedrea';
  
-- Si otro comercial desea a la vez realizar un pedido con 140 ajedreas no va a poder por el nivel de aislamiento que asignamos antes.