-- Nos conectamos como CONTABILIDAD y usamos la sentencia SYNONYM
connect contabilidad/contabilidad;
create synonym pagos for informatica.pagos;

commit;