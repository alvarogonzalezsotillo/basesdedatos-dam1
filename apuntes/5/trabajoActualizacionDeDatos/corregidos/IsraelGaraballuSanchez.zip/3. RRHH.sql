-- Nos conectamos como RRHH y usamos la sentencia SYNONYM
connect rrhh/rrhh;
create synonym oficinas for informatica.oficinas;
create synonym empleados for informatica.empleados;

commit;