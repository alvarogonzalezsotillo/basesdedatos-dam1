-- Nos conectamos como COMERCIAL y creamos al cliente PepeGardens
connect comercial/comercial;
insert into clientes(codigocliente,nombrecliente,telefono,fax,lineadireccion1,ciudad) values(1111,'PepeGardens','000000000','0000000','C/Falsa 123','Madrid');

-- Sacamos los empleados que son de Madrid con el c�digo de su jefe
select codigoempleado, nombre, codigojefe  from empleados
where codigooficina='MAD-ES';

-- El empleado de mayor rango en Madrid es Carlos, con CodigoEmpleado=3
-- Asignamos '3' a codigoempleadorepventas de PepeGardens
update clientes
  set codigoempleadorepventas = 3
  where nombrecliente = 'PepeGardens';

-- Creamos con RRHH a Manolo Bombo
connect rrhh/rrhh;
insert into empleados(codigoempleado,nombre,apellido1,extension,email,codigooficina) values(2222,'Manolo','Bombo','2443','manoloeldelbombo@gmail.com','MAD-ES');

-- Desplazamos a Carlos, el empleado de mayor rango a Barcelona
update empleados
  set codigooficina = 'BCN-ES'
  where codigoempleado = 7;
  
-- Asignamos a Manolo Bombo un jefe, en este caso era el 3
update empleados
  set codigojefe = 3
  where codigoempleado = 2222;
  
-- Asignamos que todos los que depend�an de Carlos, ahora dependan de Manolo
update empleados
  set codigojefe = 2222
  where codigojefe = 7;
  
-- PepeGardens y dem�s clientes que dependian de Carlos, ahora dependen de Manolo
connect comercial/comercial;
update clientes
  set codigoempleadorepventas = 2222
  where nombrecliente = 7;
  
update clientes
  set codigoempleadorepventas = 2222
  where nombrecliente = 'PepeGardens';