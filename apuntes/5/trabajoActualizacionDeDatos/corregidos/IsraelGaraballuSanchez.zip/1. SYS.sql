-- Creamos los usuarios y damos permisos para conectarse
connect sys/alumno as sysdba;

create user informatica identified by informatica default tablespace users;
grant connect to informatica;
grant resource to informatica;

create user rrhh identified by rrhh default tablespace users;
grant connect to rrhh;

create user comercial identified by comercial default tablespace users;
grant connect to comercial;

create user contabilidad identified by contabilidad default tablespace users;
grant connect to contabilidad;

create user jardineria identified by jardineria default tablespace users;
grant connect to jardineria;

-- Damos permisos a los usuarios para poder crear los sin�nimos
grant create synonym to rrhh, informatica, comercial, contabilidad, jardineria;

commit;