-- Nos conectamos como JARDINER�A y usamos la sentencia SYNONYM
connect jardineria/jardineria;
create synonym productos for informatica.productos;
create synonym gamasproductos for informatica.gamasproductos;

commit;