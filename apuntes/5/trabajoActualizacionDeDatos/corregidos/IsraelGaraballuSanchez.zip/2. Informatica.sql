-- Nos conectamos como Informatica e importamos las tablas
connect informatica/informatica;
@jardineria-oracle.sql

-- Damos permisos de edicion a los usuarios
grant select on informatica.oficinas to rrhh;
grant select on informatica.empleados to rrhh;
grant update on informatica.oficinas to rrhh;
grant update on informatica.empleados to rrhh;
grant insert on informatica.oficinas to rrhh;
grant insert on informatica.empleados to rrhh;
grant delete on informatica.oficinas to rrhh;
grant delete on informatica.empleados to rrhh;

grant select on informatica.clientes to comercial;
grant select on informatica.pedidos to comercial;
grant select on informatica.detallepedidos to comercial;
grant update on informatica.clientes to comercial;
grant update on informatica.pedidos to comercial;
grant update on informatica.detallepedidos to comercial;
grant update (cantidadenstock) on informatica.productos to comercial;
grant select on informatica.oficinas to comercial;
grant select on informatica.empleados to comercial;
grant insert on informatica.clientes to comercial;
grant insert on informatica.pedidos to comercial;
grant insert on informatica.detallepedidos to comercial;
grant insert on informatica.oficinas to comercial;
grant insert on informatica.empleados to comercial;
grant delete on informatica.clientes to comercial;
grant delete on informatica.pedidos to comercial;
grant delete on informatica.detallepedidos to comercial;
grant delete on informatica.oficinas to comercial;
grant delete on informatica.empleados to comercial;

grant select on informatica.pagos to contabilidad;
grant update on informatica.pagos to contabilidad;
grant insert on informatica.pagos to contabilidad;
grant delete on informatica.pagos to contabilidad;

grant select on informatica.productos to jardineria;
grant select on informatica.gamasproductos to jardineria;
grant update on informatica.productos to jardineria;
grant update on informatica.gamasproductos to jardineria;
grant insert on informatica.productos to jardineria;
grant delete on informatica.gamasproductos to jardineria;

commit;