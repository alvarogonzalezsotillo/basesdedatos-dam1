-- Seguimos como comercial y miramos cuantas palas disponemos
select cantidadenstock from productos
  where nombre='Pala';

-- Eliminamos 10 palas que son las que desea PepeGardens
update productos
  set cantidadenstock = 5
  where nombre='Pala';

-- Realizamos el pedido
insert into pedidos(codigopedido,fechapedido,fechaesperada,estado,codigocliente) values(129,to_date('030213','ddmmyy'),to_date('030213','ddmmyy'),'Entregado',1111);

-- Y a�adimos a este los productos
insert into detallepedidos(codigopedido,codigoproducto,cantidad,preciounidad,numerolinea) values(129,'AR-001',50,1,1);

insert into detallepedidos(codigopedido,codigoproducto,cantidad,preciounidad,numerolinea) values(129,'21636',10,14,2);

-- Nos conectamos como contabilidad y miramos si el saldo del cleinte es inferior a 190, que es lo que vale su pedido.
connect contabilidad/contabilidad;
select limitecredito from clientes where codigocliente=1111;

-- No le asignamos ning�n cr�dito al crearlo, asique suponemos que si dispone de ello. Procedemos a cobrar el pedido.
insert into pagos(codigocliente,formapago,idtransaccion,fechapago,cantidad) values(1111,'PayPal','ak-std-000027',to_date('030213','ddmmyy'),190);

insert into pagos(codigocliente,formapago,idtransaccion,fechapago,cantidad) values(1111,'Efectivo','ak-std-000028',to_date('030213','ddmmyy'),190);

-- Solo va a poder pagar uno por el nivel de aislamiento que asignamos antes.