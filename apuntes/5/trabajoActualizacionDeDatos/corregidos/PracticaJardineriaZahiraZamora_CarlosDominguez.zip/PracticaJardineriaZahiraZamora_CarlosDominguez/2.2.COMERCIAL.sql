-- Nos conectamos como usuario COMERCIAL
connect comercial/comercial;

--Nos creamos synonym para las tablas de las que tenemos algun permiso
-- Tablas: Clientes, Pedidos, DetallePedidos, Productos, Empleados y Oficinas.
create synonym clientes for informatica.clientes;
create synonym pedidos for informatica.pedidos;
create synonym detallepedidos for informatica.detallepedidos;
create synonym productos for informatica.productos;
create synonym empleados for informatica.empleados;
create synonym oficinas for informatica.oficinas;