-- Nos conectamos como usuario COMERCIAL
connect comercial/comercial;
set autocommit off;

commit;
set transaction isolation level serializable;

--PepeGardens desea comprar 50 ajedreas. COMERCIAL realiza una consulta para ver cu�ntas hay disponibles. Tras ello, crea 
--un pedido para PepeGardens con esas 50 ajedreas, eliminando 50 ajedreas del stock.

select codigoproducto,nombre,gama,cantidadenstock,descripcion
from productos 
where nombre like 'Ajedrea' for update;

--sufro bloqueo y cuando desbloquean no quedan ajedreas


--terminamos transaccion
commit;