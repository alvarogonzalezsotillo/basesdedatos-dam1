-- Nos conectamos como usuario JARDINERIA
connect jardineria/jardineria;

--Nos creamos synonym para las tablas de las que tenemos algun permiso
-- Tablas: Productos y GamasProductos
create synonym productos for informatica.productos;
create synonym gamasproductos for informatica.gamasproductos;