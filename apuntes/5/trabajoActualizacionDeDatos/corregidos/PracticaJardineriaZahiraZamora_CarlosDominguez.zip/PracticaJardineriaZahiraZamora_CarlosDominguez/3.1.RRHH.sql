--Mientras tanto, RRHH ha creado a un nuevo empleado en Madrid (�Manolo Bombo�). 
--RRHH est� desplazando al empleado de mayor rango de Madrid a Barcelona. 
--Para ello, est� asignando todos sus representados a �Manolo Bombo�,
--que depender� del jefe que depend�a antes el jefe de Madrid, y el resto de
--empleados de Madrid depender�n de Manolo Bombo.
connect rrhh/rrhh;
set autocommit off;
commit;
set transaction isolation level serializable;

--Uso esta informacion para ver los valores de codigoempleado y el dominio del email
select * from empleados for update;

--Uso esta informacion para sacar el codigooficina
select codigooficina from oficinas where ciudad like 'Madrid';

--busco el codigojefe de oficina madrid
--Resultado:7
Select e.codigoempleado,e.nombre,e.codigooficina,e.codigojefe
from empleados e
where (codigooficina='MAD-ES' and
        e.codigojefe in ( select codigoempleado
                     from empleados
                     where codigooficina<>'MAD-ES'))
for update;                     

--Datos de codigoempleado =7
--Resultado: Director Oficina   extension2444  jefe3 
select codigoempleado,puesto,extension,codigojefe 
from empleados 
where codigoempleado=7 for update;

--maximo codigoempleado Resultado: 31
select max(codigoempleado)
from empleados;

--agrego manolo bombo a empleados
insert into empleados
  (CODIGOEMPLEADO,NOMBRE,APELLIDO1,EXTENSION,EMAIL,CODIGOOFICINA,CODIGOJEFE,PUESTO)
  values(32,'Manolo','Bombo',2444,'m.bombo@gardening.com','MAD-ES',3,'Director Oficina');
  
--compruebo los empleados con codigojefe el anterior
select codigoempleado,codigojefe,puesto from empleados where codigojefe=7 for update;

--asigno a los empleados al nuevo jefe
update empleados set codigojefe=32 where codigojefe=7;  

--compruebo los representados de 7
select codigocliente from clientes where codigoempleadorepventas=7 for update;

--asigno los representados a 32
update clientes set codigoempleadorepventas=32 where codigoempleadorepventas=7;
  
--compruebo que personal hay en barcelona
select codigooficina from oficinas where ciudad like 'Barcelona';

--uso el codigooficina
select codigoempleado,codigojefe,puesto,extension from empleados where codigooficina like 'BCN-ES' for update;

--asigno el jefe antiguo a Barcelona
update empleados set codigooficina='BCN-ES' where codigoempleado=7;

commit;
