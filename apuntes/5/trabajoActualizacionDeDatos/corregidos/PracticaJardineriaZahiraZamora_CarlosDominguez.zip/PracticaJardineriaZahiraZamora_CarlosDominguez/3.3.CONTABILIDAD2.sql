-- Nos conectamos como usuario CONTABILIDAD
connect contabilidad/contabilidad;
set autocommit off;

commit;
set transaction isolation level serializable;


--Agrojardin realiza finalmente el pedido de 140 ajedreas, y otro de 10 palas, a trav�s de Manolo Bombo.
--Un empleado de Agrojardin se conecta por Internet para pagarlo con PayPal. Otro se acerca para pagarlo en efectivo.
--Para recibir un pago, CONTABILIDAD consulta primero el saldo del cliente (suma de todos sus pedidos menos suma de todos 
--sus pagos). Solo acepta pagos inferiores al saldo deudor del cliente.
--Aseg�rate de que s�lo un empleado de Agrojardin consigue pagar.

--Un empleado de Agrojardin se acerca a pagar el pedido en EFECTIVO

--comprobamos el codigocliente. Resultado:28
select codigocliente,nombrecliente 
from clientes 
where nombrecliente like 'Agrojardin';

--suma de los pagos de 'Agrojardin'
--para bloquear la tabla pagos ya da error Oracle usando for update con sum
--hacemos antes este select
select * from pagos where codigocliente=28 for update;
--se queda bloqueado y cuando se libera comprobamos
--Resultado: 8769
select sum(cantidad)
from pagos
where codigocliente=28; 


--comprobamos todas las lineas de pedidos para codigocliente 28
--Resultado: 8769 por lo que el pedido ya ha sido pagado(8769-8769)=0�
select sum(dp.cantidad*dp.preciounidad)
from pedidos p, detallepedidos dp
where p.codigopedido=dp.codigopedido and
       p.codigocliente=28;
       
--terminamos transaccion  
commit;  