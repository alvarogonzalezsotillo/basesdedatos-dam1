-- Nos conectamos como usuario RRHH
connect rrhh/rrhh;

--Nos creamos synonym para las tablas de las que tenemos permiso
-- Tablas: Oficinas, Empleados y Clientes.
create synonym oficinas for informatica.oficinas;
create synonym empleados for informatica.empleados;
create synonym clientes for informatica.clientes;