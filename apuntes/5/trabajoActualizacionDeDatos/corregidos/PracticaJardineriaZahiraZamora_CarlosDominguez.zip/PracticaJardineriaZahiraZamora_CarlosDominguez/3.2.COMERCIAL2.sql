--Mientras, otro COMERCIAL va a realizar la misma operaci�n con 140 ajedreas para Agrojardin.
connect comercial/comercial;
set autocommit off;
commit;
set transaction isolation level serializable;

--obtengo el stock, el codigoproducto de ajedreas y precioventa
--resultado: AR-001		Ajedrea 	140unidades		 1�
select codigoproducto, nombre, cantidadenstock, precioventa 
from productos 
where nombre like 'Ajedrea' for update;

--como hay stock busco codigo de Agrojardin Resultado:28
select codigocliente,nombrecliente 
from clientes 
where nombrecliente like 'Agrojardin';

--busco maximo codigopedido resultado: 128. Asignaremos el 129 al nuevo pedido
select max(codigopedido) from pedidos;

--busco informacion general en pedidos
select codigopedido,fechapedido,fechaesperada,fechaentrega,estado,rownum 
from pedidos 
where rownum<15 
for update;

--nueva linea para pedidos
insert into pedidos
  (codigopedido,fechapedido,fechaesperada,estado,codigocliente)
  values(129,sysdate,to_date('28/03/2013','dd/MM/YYYY'),'Pendiente',28);

insert into detallepedidos
  (codigopedido,codigoproducto,cantidad,preciounidad,numerolinea)
  values(129,'AR-001',140,1,1);
  
--descontamos 140 ajedreas del stock
update productos set cantidadenstock=cantidadenstock-140 
where codigoproducto='AR-001';

--adem�s el cliente nos llama porque quiere aumentar el pedido con 10 palas

--buscamos si quedan palas
--Resultado: 21636		Pala	15unidades		14�
select codigoproducto, nombre, cantidadenstock, precioventa 
from productos 
where nombre like '%ala' for update;

--nueva linea de pedido para el pedido 129
insert into detallepedidos
  (codigopedido,codigoproducto,cantidad,preciounidad,numerolinea)
  values(129,'21636',10,14,2);

--compruebo que el pedido esta correcto
--Resultado:  codigo129  hecho02-MAR-13		esperado28-MAR-13		Estado:Pendiente
select codigopedido,fechapedido,fechaesperada,fechaentrega,estado
from pedidos 
where codigopedido=129
for update;

--Resultado: 	 129  AR-001		    140 	   1	       1
--	           129  21636		       10 	  14	       2

select codigopedido,codigoproducto,cantidad,preciounidad,numerolinea
from detallepedidos
where codigopedido=129;
 
commit;
