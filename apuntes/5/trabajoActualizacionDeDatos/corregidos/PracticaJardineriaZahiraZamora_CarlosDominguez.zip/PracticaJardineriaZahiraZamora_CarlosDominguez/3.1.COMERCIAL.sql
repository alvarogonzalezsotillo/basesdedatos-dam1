-- Nos conectamos como usuario COMERCIAL
connect comercial/comercial;
set autocommit off;

commit;
set transaction isolation level serializable;

--COMERCIAL da de alta al nuevo cliente �PepeGardens�, en Madrid (inventa el resto de datos), sin representante.

insert into CLIENTES(codigocliente,nombrecliente,telefono,fax,lineadireccion1,ciudad)
values(39,'PepeGardens','918886416','918886415','c/federico 1,4�A','Madrid');
                
--Buscamos primero el codigo de la ciudad de madrid --> Resultado: MAD-ES

Select codigooficina, ciudad
from  oficinas
where ciudad like 'Madrid';

-- Encontrar a los empleados de mayor rango en Madrid (que no tienen un jefe en Madrid).
--> Resultado: 32 Manolo

Select e.codigoempleado,e.nombre,e.codigooficina,e.codigojefe
from empleados e
where (codigooficina='MAD-ES' and
        e.codigojefe in ( select codigoempleado
                     from empleados
                     where codigooficina<>'MAD-ES'))
for update;

--Asigno el primero de esos empleados como representante de �PepeGardens�.
update clientes set codigoempleadorepventas=32  where nombrecliente like 'PepeGardens';

--Terminamos la transaccion
commit;