--Base de Datos Jardineria
--Autor: Zahira Zamora y Carlos Dominguez

--Creacion y asignacion permisos usuario INFORMATICA
connect SYS/alumno as SYSDBA;

create user INFORMATICA identified by INFORMATICA default tablespace users;
grant connect to INFORMATICA;
grant resource to INFORMATICA;


--Volcado de estructura y datos
connect INFORMATICA/INFORMATICA;

@jardineria_oracle.sql;

-- Creacion de usuarios
connect SYS/alumno as SYSDBA;

create user RRHH identified by RRHH default tablespace users;
create user COMERCIAL identified by COMERCIAL default tablespace users;
create user CONTABILIDAD identified by CONTABILIDAD default tablespace users;
create user JARDINERIA identified by JARDINERIA default tablespace users;


--Asignacion de permisos a usuarios
grant connect to RRHH;
grant connect to COMERCIAL;
grant connect to CONTABILIDAD;
grant connect to JARDINERIA;
grant create synonym to rrhh,comercial,contabilidad,jardineria;

--Permisos a RRHH
grant select, insert, update, delete on informatica.oficinas to RRHH;
grant select, insert, update, delete on informatica.empleados to RRHH;
grant select, update (codigoempleadorepventas) on informatica.clientes to RRHH;

--Permisos a COMERCIAL
grant select, insert, update, delete on informatica.clientes to COMERCIAL;
grant select, insert, update, delete on informatica.pedidos to COMERCIAL;
grant select, insert, update, delete on informatica.detallepedidos to COMERCIAL;
grant select, update (cantidadenstock) on informatica.productos to COMERCIAL;
grant select on informatica.empleados to COMERCIAL;
grant select on informatica.oficinas to COMERCIAL;

--Permisos a CONTABILIDAD
grant select, insert, update, delete on informatica.pagos to CONTABILIDAD;
              --a�adidos para el ejercicio3.3
grant select on informatica.clientes to CONTABILIDAD;              
grant select on informatica.pedidos to CONTABILIDAD; 
grant select on informatica.detallepedidos to CONTABILIDAD;

--Permisos a JARDINERIA
grant select, insert, update, delete on informatica.productos to JARDINERIA;
grant select, insert, update, delete on informatica.gamasproductos to JARDINERIA;