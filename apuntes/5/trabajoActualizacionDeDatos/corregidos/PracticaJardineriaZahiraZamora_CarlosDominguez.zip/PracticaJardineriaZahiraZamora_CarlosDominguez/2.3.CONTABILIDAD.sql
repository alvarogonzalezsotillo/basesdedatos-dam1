-- Nos conectamos como usuario CONTABILIDAD
connect contabilidad/contabilidad;

--Nos creamos synonym para las tablas de las que tenemos algun permiso
-- Tablas: Pagos, Clientes, Pedidos y DetallePedidos
create synonym pagos for informatica.pagos;
create synonym clientes for informatica.clientes;
create synonym pedidos for informatica.pedidos;
create synonym detallepedidos for informatica.detallepedidos;