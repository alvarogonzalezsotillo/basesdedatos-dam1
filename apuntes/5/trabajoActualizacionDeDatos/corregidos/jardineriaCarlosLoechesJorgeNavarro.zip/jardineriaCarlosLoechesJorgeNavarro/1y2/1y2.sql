connect sys/alumno as sysdba

--Creaci�n de usuarios
create user informatica identified by informatica
default tablespace users;

create user rrhh identified by rrhh
default tablespace users;
 
create user comercial identified by comercial
default tablespace users;

create user contabilidad identified by contabilidad
default tablespace users;

create user jardineria identified by jardineria
default tablespace users;

--Creaci�n de base de datos
--Hay que dar permisos a inform�tica de conexi�n y de creaci�n de tablas
grant connect to informatica;
grant create table to informatica;
grant resource to informatica;
connect informatica/informatica;
@jardineria_oracle.sql

--Asignaci�n de permisos a los usuarios
connect sys/alumno as sysdba

--rrhh
grant connect to rrhh;
grant select on informatica.oficinas to rrhh;
grant select on informatica.empleados to rrhh;
grant select on informatica.clientes to rrhh;
grant insert on informatica.oficinas to rrhh;
grant insert on informatica.empleados to rrhh;
grant insert on informatica.clientes to rrhh;
grant delete on informatica.oficinas to rrhh;
grant delete on informatica.empleados to rrhh;
grant delete on informatica.clientes to rrhh;
grant update (codigooficina, ciudad, pais, region, codigopostal, telefono, lineadireccion1, lineadireccion2) on informatica.oficinas to rrhh;
grant update (codigoempleado, nombre, apellido1, apellido2, extension, email, codigooficina, codigojefe, puesto) on informatica.empleados to rrhh;
grant update on informatica.clientes to rrhh;

--comercial
grant connect to comercial;
grant select on informatica.clientes to comercial;
grant select on informatica.pedidos to comercial;
grant select on informatica.detallepedidos to comercial;
grant select on informatica.productos to comercial;
grant insert on informatica.clientes to comercial;
grant insert on informatica.pedidos to comercial;
grant insert on informatica.detallepedidos to comercial;
grant insert on informatica.productos to comercial;
grant delete on informatica.clientes to comercial;
grant delete on informatica.pedidos to comercial;
grant delete on informatica.detallepedidos to comercial;
grant delete on informatica.productos to comercial;
grant update(codigocliente, nombrecliente, nombrecontacto, apellidocontacto, telefono, fax, lineadireccion1, lineadireccion2, ciudad, region, pais, codigopostal, codigoempleadorepventas, limitecredito) on informatica.clientes to comercial;
grant update(codigopedido, fechapedido, fechaesperada, fechaentrega, estado, comentarios, codigocliente) on informatica.pedidos to comercial;
grant update(codigopedido, codigoproducto, cantidad, preciounidad, numerolinea) on informatica.detallepedidos to comercial;
grant update(cantidadenstock) on informatica.productos to comercial;
grant select on informatica.empleados to comercial;
grant select on informatica.oficinas to comercial;

--contabilidad
grant connect to contabilidad;
grant select on informatica.pagos to contabilidad;
grant select on informatica.detallespedidos to contabilidad;
grant select on informatica.pedidos to contabilidad;
grant select on informatica.clientes to contabilidad;
grant insert on informatica.pagos to contabilidad;
grant delete on informatica.pagos to contabilidad;
grant update(codigocliente, formapago, idtransaccion, fechapago, cantidad) on informatica.pagos to contabilidad;

--jardineria
grant connect to jardineria;
grant select on informatica.productos to jardineria;
grant select on informatica.gamasproductos to jardineria;
grant insert on informatica.productos to jardineria;
grant insert on informatica.gamasproductos to jardineria;
grant delete on informatica.productos to jardineria;
grant delete on informatica.gamasproductos to jardineria;
grant update(codigoproducto, nombre, gama, dimensiones, proveedor, descripcion, cantidadenstock, precioventa, precioproveedor) on informatica.productos to jardineria;
grant update(gama, descripciontexto, descripcionhtml, imagen) on informatica.gamasproductos to jardineria;


--Permisos para creaci�n de sin�nimos
grant create synonym to rrhh;
grant create synonym to comercial;
grant create synonym to contabilidad;
grant create synonym to jardineria; 

--Creaci�n de sin�nimos
connect rrhh/rrhh
create synonym oficinas for informatica.oficinas;
create synonym empleados for informatica.empleados;
create synonym clientes for informatica.clientes;

connect comercial/comercial
create synonym clientes for informatica.clientes;
create synonym pedidos for informatica.pedidos;
create synonym detallepedidos for informatica.detallepedidos;
create synonym productos for informatica.productos;
create synonym empleados for informatica.empleados;
create synonym oficinas for informatica.oficinas;

connect contabilidad/contabilidad
create synonym pagos for informatica.pagos;
create synonym detallepedidos for informatica.detallepedidos;
create synonym pedidos for informatica.pedidos;
create synonym clientes for informatica.clientes;

connect jardineria/jardineria
create synonym productos for informatica.productos;
create synonym gamasproductos for informatica.gamasproductos;


