connect rrhh/rrhh
set autocommit off
set transaction isolation level serializable;
--Miro antes cuantos empleados hay para meter el codigoempleado
select codigoempleado from empleados;
--Creo el nuevo empleado
--Depende del empleado n�mero 3 porque ese es el empleado del que depende el jefe de Madrid
insert into empleados values (40, 'Manolo', 'Bombo', 'Bombo', '1111', 'm@bombo.es', 'MAD-ES', 3, 'Director Oficina');

--Traslado al jefe de Madrid a Barcelona
--Primero miro cual es el empleado de mayor rango de Madrid.
select e.codigoempleado, e.nombre, e.apellido1, e.apellido2
from empleados e
where e.codigooficina like '%MAD-ES%'
and e.codigojefe in(select e2.codigojefe
                       from empleados e2
                       where e2.codigooficina not like '%MAD-ES%');
                       
--El resultado de la consulta es el empleado n�mero 7, Carlos Soria Jimenez
--Ahora hago el traslado
update empleados set codigooficina ='BCN-ES' where codigoempleado=7;

--Ahora asigno los clientes a Manolo Bombo, que pasan de estar representados por el 7 a estar representados
--por el c�digo de Manolo Bombo, el 40
update clientes set codigoempleadorepventas=40 where codigoempleadorepventas=7;

--Ahora asigno los empleados a Manolo Bombo, que pasan de estar dirigidos por el 7 a estar dirigidos
--por  Manolo Bombo, el 40
update empleados set codigojefe=40 where codigojefe=7 and codigooficina='MAD-ES';


commit;
