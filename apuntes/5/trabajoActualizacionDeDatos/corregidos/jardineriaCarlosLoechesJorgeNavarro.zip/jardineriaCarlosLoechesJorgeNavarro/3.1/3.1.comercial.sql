connect comercial/comercial
set autocommit off
set transaction isolation level serializable;

--Introduzco al cliente PepeGardens
insert into clientes (codigocliente, nombrecliente, nombrecontacto, apellidocontacto, telefono, fax, lineadireccion1, lineadireccion2, ciudad, region, pais, codigopostal, limitecredito) values (39, 'PepeGardens', 'Pepe', 'Lolo', 918876656, 8797856905, 'calle Hola', 'calle Mayor', 'Madrid', 'Madrid', 'Espa�a', '28454', 50000);
commit;

--Consulta para saber quien es el empleado de mayor rango de Madrid
select e.codigoempleado, e.nombre, e.apellido1, e.apellido2
from empleados e
where e.codigooficina like '%MAD-ES%'
and e.codigojefe in(select e2.codigojefe
                       from empleados e2
                       where e2.codigooficina not like '%MAD-ES%');
                       
--El resultado de la consulta es el empleado n�mero 7, Carlos Soria Jimenez

--Meto al jefe como representante de PepeGardens

update clientes
set codigoempleadorepventas=7
where codigoempleadorepventas is null;      

commit;               

                                  
                               
                                  
                                  
                                  
                                 


