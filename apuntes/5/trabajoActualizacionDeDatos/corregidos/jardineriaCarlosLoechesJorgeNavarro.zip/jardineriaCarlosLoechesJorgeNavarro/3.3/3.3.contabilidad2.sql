--Entro con el comercial para realizar tambien el pedido de palas
connect comercial/comercial
set autocommit off
set transaction isolation level read committed;

--Miro la cantidad de palas que hay en stock. Si hubiera menos de 10 haria rollback.
select cantidadenstock from productos where nombre='Pala';

--Miro el c�digo de las palas y su precio para meter el pedido. El c�digo es 21636 y el precio es 14
select codigoproducto, precioventa from productos where nombre='Pala';

--Miro si el pedido ya est� hecho. Si estuviera hecho haria rollback. El c�digo de PepeGardens era el 39.
select * from pedidos where codigocliente=39;

--Meto tambi�n una fila en la tabla detallespedidos, es el mismo pedido que en el punto anterior, el 200 de PepeGardens.
insert into detallepedidos values(200, '21636', 10, 14, 2);

--Actualizo la cantidad de palas
update productos set cantidadenstock=cantidadenstock-10 where nombre='Pala';

commit;

--Me conecto con el usuario contabilidad para guardar el pago
connect contabilidad/contabilidad
set autocommit off
set transaction isolation level read committed;

--Miro el c�digo del cliente PepeGardens. Es el 39.
select codigocliente from clientes where nombrecliente='PepeGardens';

--Miro los pedidos que ha realizado. Solo ha realizado uno, el pedido 200
select codigopedido from pedidos where codigocliente=39;

--Miro lo que debe el cliente por sus pedidos
select sum(cantidad*preciounidad) from detallepedidos where codigopedido=200;

--Ahora miro en la tabla pagos si ha pagado o no. Si sale el mism resultado que en la consulta anterior haria rollback porque ya ha pagado.
select sum(cantidad) from pagos where codigocliente=39;

--Ahora meto una fila en la tabla pagos con el que paga en efectivo.
insert into pagos values(39, 'Efectivo', 'aaaaa', to_date('04/03/2013', 'mm/dd/yyyy'), 190);

commit;