connect comercial/comercial
set autocommit off
set transaction isolation level serializable;

--consulta de cuantas ajedreas hay en stock. Si hubiera menos de 50 haria un rollback.

select cantidadenstock 
        from productos 
        where nombre='Ajedrea';
        
--Restamos las 50 ajedreas del pedido comprobando que de verdad hay 50. Si la consulta no devuelve ninguna fila hago rollback.
update productos set cantidadenstock=(select cantidadenstock-50 from productos where nombre='Ajedrea') 
where nombre='Ajedrea'
and cantidadenstock >= 50; 
commit;
    
--Si los pasos anteriores se pueden realizar seguimos adelante y realizamos el pedido.

--Realizo un bloqueo read commited para saber siempre cual fue el �ltimo pedido confirmado.
set transaction isolation level read committed;

--Busco codigo Ajedrea y su precio. Son AR-001 y 1.
select codigoproducto, precioventa from productos where nombre='Ajedrea'; 
 
--Pongo formato de fecha
alter session set nls_date_format='yyyy-mm-dd';

--Miro cual es el codigo de PepeGardens para realizar el pedido. El c�digo que devuelve es el 39.
select codigocliente from clientes where nombrecliente='PepeGardens';

--Miro el pedido para ver si ya se ha hecho. Si ya estuviera esa fila haria rollback.
select * from pedidos where nombrecliente=39;

--Miro cual fue el �ltimo pedido para meter el siguiente.
select max(codigopedido) from pedidos;

--Primero inserto una fila en la tabla pedidos
insert into pedidos VALUES (200,'2013-03-05','2013-04-06',NULL,'Pendiente',NULL,39);

--Despu�s en la tabla detallepedidos 
INSERT INTO DetallePedidos VALUES (200,'AR-001',50,1,1);

--Confirmamos la transacci�n
 commit;