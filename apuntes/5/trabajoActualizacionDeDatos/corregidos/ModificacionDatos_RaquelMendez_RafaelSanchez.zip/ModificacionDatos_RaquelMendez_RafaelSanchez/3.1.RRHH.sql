--Conexion con el usuario RRHH y se pasa a autocommite off
connect RRHH/RRHH
set autocommit off

--Seleccionar nivel de aislamiento read commited, se elige este nivel para poder ver los cambios
--tras un commit, de esta forma nos aseguramos que tras una modificacion nos enteramos de esa
--informacion antes de realizar algun cambio.
set transaction isolation level read committed;

--Extraemos el codigo de oficina que pertenece a Madrid
select codigooficina, ciudad
from oficinas
where ciudad like '%Madrid%';
--el resultado es 'MAD-ES'

--Se busca el empleado de mayor rango de Madrid
select codigoempleado, nombre, codigojefe, ciudad
from empleados e, oficinas o
where e.codigooficina=o.codigooficina and
	ciudad like '%Madrid%';
--De esta forma se obtiene una lista de cuatro empleados, de los cuales solamente uno no tiene un jefe
--que se encuentre en la misma tabla (Es el empleado con codigo 7, carlos, su jefe es el empleado con
--el codigo 3, al no estar en esta tabla entendemos que no es de Madrid.

--Se inserta el nuevo empleado Manolo Bombo
insert into empleados (codigoempleado, nombre, apellido1, extension, email, codigooficina, codigojefe)
				values(32, 'Manolo', 'Bombo','3211' ,'manolobombo@gardening.com','MAD-ES', 3); 

--Bloqueamos la tabla de empleados
select * from empleados for update;

--Ahora se cambian los codigos de jefe del resto de empleados (8,9,10) de madrid (los tres que no son Carlos) a
--codigo de jefe 32 (el de Manolo) 
update empleados
set codigojefe=32
where codigojefe=7;

--Extraemos el codigo de oficina que pertenece a Barcelona
select codigooficina, ciudad
from oficinas
where ciudad like '%Barcelona%';
--el resultado es 'BCN-ES'

--Cambiamos el codigo de oficina de Carlos a Barcelona
update empleados
set codigooficina='BCN-ES'
where codigoempleado=7;

--Cambiamos los representados por Carlos a Manolo, nos encontramos la tabla bloqueada, al terminar de realizarse
--los cambios se ha modificado una fila.
update clientes
set codigoempleadorepventas=32
where codigoempleadorepventas=7; 

--Hacemos commit para formalizar los cambios y desbloquear las tablas
commit; 