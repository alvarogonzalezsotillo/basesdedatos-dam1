-- Conexion como usuario COMERCIAL.
connect COMERCIAL/COMERCIAL

-- Creacion de sinonimos para el usuario COMERCIAL.
create synonym EMPLEADOS for INFORMATICA.EMPLEADOS;
create synonym CLIENTES for INFORMATICA.CLIENTES;
create synonym OFICINAS for INFORMATICA.OFICINAS;
create synonym PAGOS for INFORMATICA.PAGOS;
create synonym GAMASPRODUCTO for INFORMATICA.GAMASPRODUCTO;
create synonym PRODUCTOS for INFORMATICA.PRODUCTOS;
create synonym PEDIDOS for INFORMATICA.PEDIDOS;
create synonym DETALLEPEDIDOS for INFORMATICA.DETALLEPEDIDOS;

-- desconexion como usuario COMERCIAL.
disconnect 