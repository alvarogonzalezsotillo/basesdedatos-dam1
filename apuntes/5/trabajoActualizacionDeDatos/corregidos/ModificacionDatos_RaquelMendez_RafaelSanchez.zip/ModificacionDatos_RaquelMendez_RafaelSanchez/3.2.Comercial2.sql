--nos conectamos como un segundo comercial y se pasa a autocommite off
connect comercial/comercial
set autocommit off

--Seleccionar nivel de aislamiento read commited, se elige este nivel para poder ver los cambios
--tras un commit, de esta forma nos aseguramos que tras una modificacion nos enteramos de esa
--informacion antes de realizar algun cambio.
set transaction isolation level read committed;

--Este comercial se encargará de la compra de 140 ajedreas para Agrojardin

--Se realiza una consulta para ver cuantas estan disponibles
select codigoproducto, nombre, cantidadenstock 
from productos
where nombre like '%Ajedrea%';
--Nos encontramos el acceso bloqueado y tenemos que esperar, pues se esta aciendo una transaccion

--Aparece el resultado de 90 ajedreas, se le comunica a Agrojardin que en estos momentos
--no se puede realizar la compra y que cuando se reponga el stock se le podra suministrar el
--producto solicitado.

--Al no realizarse cambio alguno, simplemente una query, no es necesario hacer commit, ni rollback.