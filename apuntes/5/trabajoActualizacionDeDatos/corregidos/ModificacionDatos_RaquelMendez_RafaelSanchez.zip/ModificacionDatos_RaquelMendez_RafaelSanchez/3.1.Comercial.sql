--Conexion con el usuario COMERCIAL
 connect COMERCIAL/COMERCIAL
 
--Ponemos el commit automatico desactivado para controlar las transacciones.
set autocommit off

--Seleccionando nivel de aislamiento, elegimos el nivel read committed para ver los cambios confirmados de los demás,
--si pusiereamos serializable solo veriamos nuestros propios cambios y nos interesa saber los cambios ya confirmados 
--de otros usuarios.
set transaction isolation level read committed;

-- Insertamos al nuevo cliente PepeGardens
insert into clientes (codigocliente,nombrecliente,telefono,fax,lineadireccion1,ciudad)
values (1122,'PepeGardens','918853261','918853261','Gran Via 3', 'Madrid');

--Hacemos commit para insertar al cliente de forma efectiva.
commit;

--Consulta para ver los empleados de Madrid. Ya que necesitamos conocer qué empleados hay en Madrid
--para saber cual de ellos asignar a nuestro nuevo cliente. Tambien pedimos el codigo de jefe de los
--empleados, para conocer a de quien depende cada empleado.
select codigoempleado, nombre,ciudad,codigojefe
from empleados e, oficinas o
where ciudad like 'Madrid' and o.codigooficina=e.codigooficina;

--Con la consulta anterior obtenemos los empleados de Madrid con su codigo de jefe,
--el codigo de jefe y empleado coinciden, entonces vemos que solo hay 4 empleados en Madrid,
--3 con codigo de jefe 7 (que es un codigo de empleado de Madrid, Carlos)y otro con codigo de jefe 3.
--Ahora buscaremos informacion acerca del empleado con el codigo de empleado 3, que es jefe del de codigo de empleado 7
--y vemos que no se encuentra en la oficina de Madrid sino en Talavera. Con lo cual el jefe de Madrid que no tiene jefes
--en la misma oficina es el de código de empleado 7.
select codigoempleado,nombre,ciudad,codigojefe
from empleados e, oficinas o
where codigoempleado=3 and e.codigooficina=o.codigooficina;

--Bloqueamos la tabla clientes para asignar correctamente el representante de ventas y no pueda otro usuario
--de la base de datos modificarlo al mismo tiempo.
select * from clientes for update;

--Una vez encontrado el empleado de mayor rango en Madrid se lo asignamos a PepeGardens, este era el de código de empleado 7.
update clientes
set codigoEmpleadoRepVentas=7
where codigocliente=1122;

--comprobamos que ha ido todo correctamente que el cliente ha sido asignado al empleado con codigo de empleado 7,
--que es Carlos. El empleado de mayor rango en Madrid cuyo jefe no es de Madrid.
select nombreCliente, codigoCliente,codigoEmpleadoRepVentas
from clientes
where codigoCliente=1122;

--Como hemos comprobado ha quedado asignado al representante de ventas adecuado, Carlos con el número de codigo de empleado 3.
--Asi que realizamos un commit.
commit;

--Ahora nos desconectamos como comercial.
disconnect
