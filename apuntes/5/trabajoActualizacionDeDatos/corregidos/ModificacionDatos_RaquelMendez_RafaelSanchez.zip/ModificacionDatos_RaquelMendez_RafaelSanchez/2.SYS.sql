--Identificacion como administrador de la Base de Datos para la creacion de usuarios.

connect sys/alumno as sysdba 

--Creacion de todos los usuarios de la BB.DD con sus respectivas contraseñas.
create user INFORMATICA identified by INFORMATICA
default tablespace users;  
create user COMERCIAL identified by COMERCIAL
default tablespace users;
create user RRHH identified by RRHH
default tablespace users;
create user CONTABILIDAD identified by CONTABILIDAD
default tablespace users;
create user JARDINERIA identified by JARDINERIA
default tablespace users;

--Otorgamos permisos al usuario INFORMATICA para que pueda conectarse y crear las tablas.
grant connect to INFORMATICA;
grant resource to INFORMATICA;

--Otorgamos permisos de conexion al resto de usuarios
grant connect to COMERCIAL;
grant connect to RRHH;
grant connect to CONTABILIDAD;
grant connect to JARDINERIA;

--Adjudicamos permiso de creacion de sinonimos al usuario INFORMATICA y al resto de usurios;
grant create synonym to INFORMATICA,COMERCIAL,RRHH,CONTABILIDAD,JARDINERIA;

--Dexconexion como usuario SYS.
disconnect 