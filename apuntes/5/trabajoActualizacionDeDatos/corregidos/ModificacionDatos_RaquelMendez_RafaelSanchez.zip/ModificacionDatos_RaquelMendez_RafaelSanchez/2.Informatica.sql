--conexion como usuario Informatica
connect INFORMATICA/INFORMATICA

--Creacion de las tablas
@jardineria_oracle.sql
commit;

--Este usuario no hace sinonimos, pues las tablas las ha creado el; por lo tanto
--accede de manera directa sin mencionar al usuario que creo las tablas pues es el mismo.

--Otorgacion de permisos sobre las tablas al usuario RRHH, permisos para ver y modificar tablas.
grant select on oficinas to RRHH;
grant update on oficinas to RRHH;
grant select on empleados to RRHH;
grant update on empleados to RRHH;
grant insert on empleados to RRHH;
grant update (codigoEmpleadoRepVentas) on clientes to RRHH;

--Otorgacion de permisos sobre las tablas al usuario COMERCIAL, permisos para ver,modificar tablas y realizar inserciones.
grant select on pedidos to COMERCIAL;
grant update on pedidos to COMERCIAL;
grant select on clientes to COMERCIAL;
grant update on clientes to COMERCIAL;
grant select on detallepedidos to COMERCIAL;
grant update on detallepedidos to COMERCIAL;
grant select on oficinas to COMERCIAL;
grant select on empleados to COMERCIAL;
grant select on Productos to COMERCIAL;
grant update (CantidadEnStock) on Productos to COMERCIAL;
grant insert on clientes to COMERCIAL;
grant insert on pedidos to COMERCIAL;
grant insert on detallepedidos to COMERCIAL;

--Otorgacion de permisos sobre las tablas al usuario CONTABILIDAD, permisos para ver y modificar tablas.
grant select on pagos to CONTABILIDAD;
grant update on pagos to CONTABILIDAD;
grant insert on pagos to CONTABILIDAD;
grant select on clientes to CONTABILIDAD;
grant select on pedidos to CONTABILIDAD;
grant select on detallePedidos to CONTABILIDAD;

--Otorgacion de permisos sobre las tablas al usuario JARDINERIA, permisos para ver y modificar tablas.
grant select on productos to JARDINERIA;
grant update on productos to JARDINERIA;
grant select on gamasProductos to JARDINERIA;
grant update on gamasProductos to JARDINERIA;

--Desconexion con el usuario INFORMATICA.
disconnect 