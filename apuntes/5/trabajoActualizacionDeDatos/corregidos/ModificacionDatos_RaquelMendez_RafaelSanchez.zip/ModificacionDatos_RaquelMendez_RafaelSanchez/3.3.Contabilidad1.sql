--Conectamos como contabilidad 
connect contabilidad/contabilidad

--Quitamos los commit automaticos para controlar las transacciones.
set autocommit off

--Ponemos un nivel de aislamiento read committed para ver los cambios confirmados de los otros.
--usuarios de la base de datos.
set transaction isolation level read committed;

--Para proceder con el pago vamos a ver los pedidos a nombre de PepeGardens, primero debemos mirar su codigo de cliente.
select codigoCliente
from clientes
where nombreCliente like '%PepeGardens%';

--Ya tenemos el codigo de cliente de PepeGardens que es el 1122. Ahora vamos a mirar los pedidos que tiene.
select codigopedido,codigocliente
from pedidos
where codigoCliente like '1122';

--Vemos que PepeGardens tiene dos pedidos a su nombre, vamos a ver el detallePedido de esos pedidos.
--Esos dos pedidos tienen c�digoPedido 3456 y 3656. Primero miramos uno y despues el otro.Comprobamos que el pedido
--3456 (Ajedreas) es de 50 euros y el pedido 3656 (palas) es de 100 euros.
select (cantidad *precioUnidad)
from detallePedidos
where codigoPedido like '3456';

select (cantidad *precioUnidad)
from detallePedidos
where codigoPedido like '3656';

--Ahora vamos a ver los pagos realizados por PepeGardens.Al realizar la consulta no aparecen pagos
--con lo que el cliente no ha realizado ningun pago todavia.
select * 
from pagos
where codigoCliente like '1122';

--Ahora vamos a proceder a cobrarle los pedidos uno a uno. Para ello primero bloqueamos la tabla.
select * 
from pagos
for update;

--Vamos a mirar las formas de pago y como son los idTransaccion para poder poner correctamente dicho id.
select distinct formaPago
from pagos;

select idtransaccion, codigocliente
from pagos;

--Vamos a introducir los datos de pago de los pedidos uno a uno;
insert into pagos (codigoCliente, formaPago, IdTransaccion,fechaPago,cantidad)
			values( 1122,'PayPal','ak-std-000056',to_date('04/03/2013','dd/MM/YYYY'),50);

insert into pagos (codigoCliente, formaPago, IdTransaccion,fechaPago,cantidad)
			values( 1122,'PayPal','ak-std-000057',to_date('04/03/2013','dd/MM/YYYY'),100);
			
--Hemos realizado los pagos, vamos a comprobar que no haya cambiado nada antes de hacerlos efectivos. Vemos que hay dos pagos que son
--que son los que hemos introducido nosotros
select * 
from pagos
where codigoCliente like '1122';

--Como todo esta bien hacemos un commit
commit;
			