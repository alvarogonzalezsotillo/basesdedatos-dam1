
--conectamos como comercial
connect comercial/comercial

--Primero desactivamos el commit automatico para controlar nosotros las transacciones.
set autocommit off

--Ponemos el nivel de aislamiento elegimos el nivel read committed para ver 
--los cambios confirmados de los dem�s,si pusiereamos serializable solo veriamos nuestros propios cambios 
--y nos interesa saber los cambios ya confirmados de otros usuarios.
set transaction isolation level read committed;

--consulta para ver el numero de ajedreas disponibles en stock y su c�digo de producto.
select codigoproducto, nombre, cantidadenstock
from productos
where nombre like 'Ajedrea'
for update;

--Hago un select para ver el tipo de estados de un pedido para luego introducir bien los datos.
select distinct (estado)
from pedidos;

--Hago una select para ver el codigo de cliente de PepeGarden, para introducirlo en los datos del pedido.
select codigocliente, nombrecliente
from clientes
where nombrecliente like 'PepeGardens';

--Ahora creamos un pedido para PepeGardens, con los datos necesarios. 
insert into pedidos (codigopedido, fechapedido, fechaesperada,estado,codigocliente)
			values (3456, to_date('27/02/2013','dd/MM/YYYY'),to_date('01/03/2013','dd/MM/YYYY'),'Pendiente',1122);

--Antes de realizar el detalle del pedido vamos a ver el codigo de la ajedrea y el precio.
select codigoproducto, precioventa
from productos
where nombre like 'Ajedrea';			
			
--Ahora realizamos el detalle del pedido, para especificar la cantidad. El codigo de la ajedrea es AR-001 y el precio
--es 1.
insert into detallepedidos (codigopedido,codigoproducto,cantidad,preciounidad,numerolinea)
			values(3456, 'AR-001',50,1,5);
			
--Ahora eliminamos las 50 ajedreas del stock, habia 140 y debemos quitar 50.
update productos
set cantidadenstock =140-50
where codigoProducto= (select codigoproducto
						from productos
						where nombre like 'Ajedrea');

--Ahora comprobamos antes de realizar el pedido que la cantidad en stock ha disminuido
select codigoproducto, nombre, cantidadenstock
from productos
where nombre like 'Ajedrea'
for update;

--Tambien comprobamos que se ha creado el pedido y el detallepedido de PepeGardens, para ello usamos el codigocliente de PepeGardens.
select codigopedido,codigocliente
from pedidos
where codigocliente like '1122';

select codigopedido,codigoproducto,cantidad
from detallepedidos
where codigopedido like '3456';

--Como todo se ha realizado correctamente hacemos efectiva la transaccion
commit;

--Ahora nos desconectamos de la base de datos
disconnect