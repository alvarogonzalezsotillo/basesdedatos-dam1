--nos conectamos como un segundo usuario de contabilidad y se pasa a autocommit off
connect contabilidad/contabilidad
set autocommit off

--Seleccionar nivel de aislamiento read commited, se elige este nivel para poder ver los cambios
--tras un commit, de esta forma nos aseguramos que tras una modificacion nos enteramos de esa
--informacion antes de realizar algun cambio.
set transaction isolation level read committed;

--Primero se consulta el saldo del cliente (suma de todos sus pedidos menos la suma de todos sus pagos)

--Lo primero es mirar los pedidos que ha realizado PepeGardens, para ver cuanto dinero debe pagar en total.
--Al realizar esta query vemos que suman un total de 150 euros.
select nombrecliente, estado, sum(cantidad*preciounidad)
from clientes c, pedidos p, detallepedidos d
where nombrecliente like '%PepeGardens%' and 
		c.codigocliente=p.codigocliente and
		p.codigopedido=d.codigopedido
group by nombrecliente,estado;

	
--Ahora vamos a ver si ha realizado algun pago. Vemos que ha realizado un pago de 150 euros, por lo cual
--no debe nada. Por lo tanto no tenemos que realizar ningun pago.
select nombrecliente, sum(cantidad)
from clientes c, pagos pa
where c.nombrecliente like '%PepeGardens%' and
	c.codigocliente=pa.codigocliente
group by nombrecliente;

--Se le comunica al cliente que el pago a sido realizado ya.

--Al no realizarse cambio alguno, simplemente una query, no es necesario hacer commit, ni rollback.