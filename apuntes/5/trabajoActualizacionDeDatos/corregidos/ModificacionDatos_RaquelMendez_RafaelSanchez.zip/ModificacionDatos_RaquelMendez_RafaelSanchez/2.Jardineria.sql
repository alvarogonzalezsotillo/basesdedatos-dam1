--Conexion como usuario JARDINERIA
connect JARDINERIA/JARDINERIA

--Creacion de sinonimos para el usuario JARDINERIA

create synonym EMPLEADOS for INFORMATICA.EMPLEADOS;
create synonym CLIENTES for INFORMATICA.CLIENTES;
create synonym OFICINAS for INFORMATICA.OFICINAS;
create synonym PAGOS for INFORMATICA.PAGOS;
create synonym GAMASPRODUCTOS for INFORMATICA.GAMASPRODUCTOS;
create synonym PEDIDOS for INFORMATICA.PEDIDOS;
create synonym PRODUCTOS for INFORMATICA.PRODUCTOS;
create synonym DETALLEPEDIDOS for INFORMATICA.DETALLEPEDIDOS;


--Desconexion como usuario jardineria.
disconnect 