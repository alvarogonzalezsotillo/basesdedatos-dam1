
--conectamos como comercial
connect comercial/comercial

--Primero desactivamos el commit automatico para poder tener control sobre las transacciones.
set autocommit off;

--Ponemos un nivel de aislamiento para ver los cambios confirmados de los otros.
set transaction isolation level read commited;

--Consultamos el numero de palas disponibles. Y bloqueamos la tabla para que otro no pueda
--vender las palas mientras nosotros estamos realizando el pedido.
select codigoproducto, nombre, cantidadEnStock
from productos
where nombre like '%Pala%'
for update;

--Como hay palas suficientes realizamos el pedido. Primero miramos el codigo de cliente de PepeGardens.
select codigocliente, nombrecliente
from clientes
where nombrecliente like 'PepeGardens';

--Ahora que ya tenemos el codigo de cliente y el codigo de producto realizamos el pedido

insert into pedidos (codigopedido, fechapedido, fechaesperada,estado,codigocliente)
			values (3656, to_date('28/02/2013','dd/MM/YYYY'),to_date('03/03/2013','dd/MM/YYYY'),'Pendiente',1122);

--Para realizar el detalle pedido nos hara falta el precio y codigo del producto
select codigoproducto, precioventa
from productos
where nombre like '%Pala%';

--Realizamos ahora que disponemos de todos los datos el detallePedido
insert into detallepedidos (codigopedido,codigoproducto,cantidad,preciounidad,numerolinea)
			values(3656, '21636',10,10,5);

--Eliminamos del Stock el numero de palas que hemos vendido
update productos
set cantidadenstock =14-10
where codigoProducto= (select codigoproducto
						from productos
						where nombre like '%Pala%');
						
--Antes de hacer commit y realizar todos los cambios comprobamos que la cantidad en stock haya disminuido. y podemos
--comprobar que ya solo quedan 4 palas en Stock
select codigoproducto, nombre, cantidadenstock
from productos
where nombre like '%Pala%';

--Tambien comprobamos que se ha creado el pedido y el detallepedido de correctamente, 
--para ello usamos el codigocliente de PepeGardens. Y el codigo de pedido para ver que se le ha asignado la cantidad correctamente.
select codigopedido,codigocliente
from pedidos
where codigocliente like '1122';

select codigopedido,codigoproducto,cantidad
from detallepedidos
where codigopedido like '3656';

--Como todos los datos son correctos confirmamos todos los cambios realizados.
commit;
