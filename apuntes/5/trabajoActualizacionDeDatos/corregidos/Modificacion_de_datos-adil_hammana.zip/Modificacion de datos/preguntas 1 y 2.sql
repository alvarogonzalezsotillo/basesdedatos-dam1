
-- connectamos como superusuario
connect sys as sysdba/alumno;

SELECT USERNAME FROM DBA_USERS;

create user informatica identified by informatica default tablespace users;
create user rrhh identified by rrhh default tablespace users;
create user comercial identified by comercial default tablespace users;
create user contabilidad identified by contabilidad default tablespace users;
create user jardineria identified by jardineria default tablespace users;

grant connect to informatica;
grant connect to rrhh;
grant connect to comercial;
grant connect to contabilidad;
grant connect to jardineria;

--INFORMATICA: Permisos completos sobre todas las tablas
grant resource to informatica;

CREATE SYNONYM empleados FOR informatica.empleados;
CREATE SYNONYM oficinas FOR informatica.oficinas;
CREATE SYNONYM cuentas FOR informatica.cuentas;
CREATE SYNONYM pedidos FOR informatica.pedidos;
CREATE SYNONYM detallepedidos FOR informatica.detallepedidos;
CREATE SYNONYM productos FOR informatica.productos;
CREATE SYNONYM gamasproductos FOR informatica.gamasproductos;
CREATE SYNONYM pagos FOR informatica.pagos;

--RRHH: Podr� modificar filas de las tablas Oficinas y Empleados


grant insert on informatica.empleados to rrhh;
grant insert on informatica.oficinas to rrhh;
grant select on informatica.empleados to rrhh;
grant select on informatica.oficinas to rrhh;
grant update on informatica.empleados to rrhh;
grant update on informatica.oficinas to rrhh;



-- COMERCIAL: Podr� modificar filas de las tablas Clientes, Pedidos y DetallePedidos.  Podr� modificar datos de la columna Productos.CantidadEnStock. Podr� ver la tabla Empleados y Oficinas.

grant insert on informatica.clientes to comercial;
grant insert on informatica.pedidos to comercial;
grant insert on informatica.DetallePedidos to comercial;
grant insert on informatica.Productos to comercial;

grant select on informatica.clientes to comercial;
grant select on informatica.pedidos to comercial;
grant select on informatica.DetallePedidos to comercial;
grant select on informatica.Productos to comercial;

grant update on informatica.clientes to comercial;
grant update on informatica.pedidos to comercial;
grant update on informatica.DetallePedidos to comercial;
grant update on informatica.Productos to comercial;

grant select on informatica.Empleados to comercial;
grant select on informatica.oficinas to comercial;

--	CONTABILIDAD: Podr� modificar filas de la tabla Pagos.

grant insert on informatica.pagos to contabilidad;
grant select on informatica.pagos to contabilidad;
grant update on informatica.pagos to contabilidad;

--	JARDINERIA: Podr� modificar filas de las tablas Productos y GamasProductos

grant insert on informatica.Productos to jardineria;
grant insert on informatica.GamasProductos to jardineria;

grant update on informatica.Productos to jardineria;
grant update on informatica.GamasProductos to jardineria;

grant select on informatica.Productos to jardineria;
grant select on informatica.GamasProductos to jardineria;

commit;
