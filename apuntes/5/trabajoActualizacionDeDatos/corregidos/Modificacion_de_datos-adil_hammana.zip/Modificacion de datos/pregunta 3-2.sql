connect comercial/comercial
set autocommit off
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
-- veremos lo que tenemos en stock
 
 select distinct nombre, codigoproducto, cantidadenstock from productos where nombre= 'Ajedrea';
 --crear un pedido de 50 Ajedreas en detalle pedidos 
INSERT INTO Pedidos ( CodigoPedido, FechaPedido, FechaEsperada, FechaEntrega, Estado, Comentarios, CodigoCliente) VALUES (200,'2013-01-18','2013-01-19','2013-01-25','Entregado','Pagado a plazos',40);
INSERT INTO DetallePedidos (CodigoPedido, CodigoProducto, Cantidad, PrecioUnidad, NumeroLinea) VALUES (200,'AR-001',50,33,88);
commit;

--en otra cosola de SQL connectamos otro usuario

connect comercial/comercial
set autocommit off
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

--buscamos codigo cliente de Agrojard�n
 select distinct nombrecliente, codigocliente from clientes where nombrecliente = 'Agrojardin';
 
 --no le va a dejar hasta que el otro empleado acabe su operacion, lectura sucia
 INSERT INTO Pedidos ( CodigoPedido, FechaPedido, FechaEsperada, FechaEntrega, Estado, Comentarios, CodigoCliente) VALUES (201,'2013-01-19','2013-01-26','2013-01-30','En espera','No pagado',28);
INSERT INTO DetallePedidos (CodigoPedido, CodigoProducto, Cantidad, PrecioUnidad, NumeroLinea) VALUES (201,'AR-001',150,33,78);