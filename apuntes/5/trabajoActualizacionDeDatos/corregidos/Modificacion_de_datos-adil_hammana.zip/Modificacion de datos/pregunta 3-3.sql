
-- nos connectamos como comercial para meter el pedido de palas porque los de contabilidad no tienen permiso para modificar esa tabla
connect comercial/comercial
INSERT INTO Pedidos ( CodigoPedido, FechaPedido, FechaEsperada, FechaEntrega, Estado, Comentarios, CodigoCliente) VALUES (220,'2013-01-28','2013-02-02','2013-02-14','Entregado','Pendiente',40);
INSERT INTO DetallePedidos (CodigoPedido, CodigoProducto, Cantidad, PrecioUnidad, NumeroLinea) VALUES (220,'AR-001',50,33,88);
--miramos el codigo de palas el stock que hay
 select nombre, codigoproducto, cantidadenstock, precioventa from productos where nombre='Pala';
  select preciounidad, cantidad from detallepedidos where codigoproducto='21636 ';
  commit;
  --nos connectamos con un usuario de contabilidad
connect contabilidad/contabilidad
set autocommit off
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

select idtransaccion, cantidad, formapago from pagos where codigocliente=40;

commit;