connect comercial/comercial
set autocommit off
set transaction isolation level serializable;
--COMERCIAL da de alta al nuevo cliente �PepeGardens�, en Madrid (inventa el resto de datos), sin representante

INSERT INTO Clientes( CodigoCliente, NombreCliente, NombreContacto, ApellidoContacto, Telefono, Fax, LineaDireccion1, LineaDireccion2, Ciudad, Region, Pais, CodigoPostal, CodigoEmpleadoRepVentas, LimiteCredito) VALUES (40,'PepeGardens',null,null,'912453218','34912484665','C/Nueva Alcala 33',NULL,'Madrid','Madrid','Spain','28004',12,11000);
commit;

-- consulta encontrar a los empleados de mayor rango en Madrid (que no tienen un jefe en Madrid)

select distinct e.codigoEmpleado, e.nombre, e.apellido1,e.apellido2
from empleados e
where e.codigoOficina like '%MAD-ES%'
and e.codigoEmpleado in (select e2.codigojefe
from empleados e2 where e2.codigoOficina not like '%Madrid%');

-- poner el contacto 'carlos' al cliente 'PepeGardens'
update clientes set NombreContacto= 'Carlos'
where NombreCliente= 'PepeGardens' ;
--haciendo un commit
commit;

connect rrhh/rrhh
set autocommit off
set transaction isolation level serializable;
 
-- hay que ver primero cuantos empleados hay para meter el codigo empleado
select codigoempleado from empleados;
-- creo 'Manolo Bombo' en Madrid
INSERT INTO Empleados( CodigoEmpleado, Nombre, Apellido1,Apellido2, Extension, Email, CodigoOficina, CodigoJefe, Puesto) 
  VALUES (100,'Manolo','Bombo',NULL,'8857','manolo.bombo@jardineria.es','Mad-ES',NULL,NULL);
--RRHH buscamos el empleado de mayor rango de Madrid 
select distinct codigoEmpleado, nombre, apellido1, apellido2, puesto
from empleados 
where codigoOficina like '%MAD-ES%' and Puesto like'%Director%';

--desplazamos el empleado a barcelona
update Empleados set CodigoOficina= 'BCN-ES'
where CodigoEmpleado=7;
--asignamos a 'Manolo Bombo' que sea el responsable de los representantes
update Empleados set CodigoOficina= 'Mad-ES', puesto='Director'
where CodigoEmpleado=100;

commit;
