--creacio de usuarios----

create user informatica identified by  informatica default tablespace users;
Grant resource to informatica---perimite cargar el archivo.---

create user RRHH identified by RRHH default tablespace users;

create user comercial identified by comercial default tablespace users;

create user contabilidad identified by contabilidad default tablespace users;

create user jardineria identified by jardineria default tablespace users;

---Otorgamos permisos al usuario informatica--
connect informatica
pass:informatica
@jardineria_oracle.sql

----creacion de permisos para la conexion del usuario--

Grant connect to informatica;
Grant connect to RRHH;
Grant connect to comercial;
Grant connect to contabilidad;
Grant connect to jardineria;


--------------------------------------------------------------------------------------------------------------

--Permisos del usuario RRHH--
--RRHH: Podr� modificar filas de las tablas Oficinas y Empleados--
Grant select on informatica.oficinas to RRHH;
Grant select on informatica.empleados to RRHH;

Grant update(CodigoOficina,Ciudad, Pais, Region, CodigoPostal,Telefono,LineaDireccion1,LineaDireccion2) on informatica.oficinas to RRHH
Grant update( CodigoEmpleado, Nombre, Apellido,Apellido2, Extension,Email, CodigoOficina,CodigoJefe,Puesto)on informatica.empleados to RRHH;

------------------------------------------------------------------------------------------------------------------
--Permisos al usuario comercial--
COMERCIAL: Podr� modificar filas de las tablas Clientes, Pedidos y DetallePedidos. Podr�
modificar datos de la columna Productos.CantidadEnStock. Podr� ver la tabla Empleados y
Oficinas.
Grant select on informatica.clientes to comercial;
Grant select on informatica.pedidos to comercial;
Grant select on informatica.detallepedidos to comercial;
Grant select on informatica.empleados to comercial;
Grant select on informatica.oficinas to comercial;

--modificar la tabla de cliente---
Grant update(CodigoCliente, NombreCliente,NombreContacto,ApellidoContacto,Telefono,Fax,LineaDireccion1,LineaDireccion2,Ciudad,Region,Pais,CodigoPostal,CodigoEmpleadoRepVentas,LimiteCredito) on informatica.clientes to comercial;
--modificar la tabla de detallepedidos--
Grant update (CodigoPedido,CodigoProducto, Cantidad,PrecioUnidad,NumeroLinea)on informatica.detallepedidos to comercial;
--modificar la tabla pedidos---
Grant update (CodigoPedido,FechaPedido,FechaEsperada,FechaEntrega,Estado,Comentarios,CodigoCliente)on informatica.pedidos to comercial;
--modificar los datos de la columna Productos.CantidadEnStock-------
Grant update (CantidadEnStock) on informatica.productos to comercial;
--podra ver la tabla empleados y oficinas---
Grant select on informatica.empleados to comercial;
Grant select on informatica.oficinas to comercial;
------------------------------------------------------------------------------------------------------------------------
-------perimisos de inserccion al usuario comercial---
Grant insert on informatica.clientes to comercial;
Grant insert on informatica.detallepedidos to comercial;
Grant insert on informatica.pedidos to comercial;
Grant insert on informatica.productos to comercial;
Grant insert on informatica.empleados to comercial;
Grant insert on informatica.oficinas to comercial;

--permisos de borrado del usuario comercial---
Grant delete on informatica.clientes to comercial;
Grant delete on informatica.detallepedidos to comercial;
Grant delete on informatica.pedidos to comercial;
Grant delete on informatica.productos to comercial;
Grant delete  on informatica.empleados to comercial;
Grant delete on informatica.oficinas to comercial;




-------------------------------------------------------------------------------------------------
--Permisos al usuario contabilidad--
Grant update( CodigoCliente,FormaPago,IDTransaccion,FechaPago,Cantidad)on informatica.pagos to comercial;

--permisos al usuario de jardineria--
--podra modificar las filas de las tablas productos y gamas productos--
Grant update(CodigoProducto,Nombre,Gama ,Dimensiones,Proveedor,Descripcion, CantidadEnStock,PrecioVenta,PrecioProveedor)on informatica.productos to jardineria;

Grant update(Gama,DescripcionTexto,DescripcionHTML,Imagen)on informatica.gamasproductos to jardineria;

-------------------------------------------------------------------
--creacion de sinonimos---

connect sys as sysdba;
Grant create synonym to RRHH;
Grant create synonym to comercial;  
Grant create synonym to contabilidad;
Grant create synonym to jardineria;

--sinonimos del usuario RRHH--

connect  RRHH/RRHH;
create Synonym oficinas for informatica.oficinas;
create synonym empleados for informatica.empleados;


--sinonimos del ususario comercial---
connect comercial/comercial;
create synonym clientes for informatica.clientes;
create synonym pedidos for informatica.pedidos;
create synonym detallepedidos for informatica.detallepedidos;
create synonym empleados for informatica.oficinas;
create synonym oficinas for informatica.oficinas;
create synonym pagos for informatica.pagos;

----sinonimos del usuario jardineria---
connect jardineria/JARDINERIA;
create synonym productos for informatica.productos;
create synonym gamasproductos for informatica.gamasproductos.




----------------------------------------------------------------------------------------------------------------------------------






