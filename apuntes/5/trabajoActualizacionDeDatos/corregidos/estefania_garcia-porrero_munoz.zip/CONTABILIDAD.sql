--Se conecta a la base de datos
connect contabilidad/contabilidad

--Synonyms tablas tablas pagos

create synonym pagos for informatica.pagos;

--Un empleado de PepeGardens pagara con PayPal. Otro se acerca para pagarlo en efectivo.
--Para el primer empleado Primero miramos que tiene que pagar el cliente 
select preciounidad*cantidad
from detallepedidos
where codigopedido=150;

select preciounidad*cantidad
from detallepedidos
where codigopedido=155;
--Y despues el total de pagos que se han efectuado
select cantidad
from pagos
where codigocliente=11111;-- el cliente no ha efectuado ningun pago por lo tanto se hace la transaccion
--realizamos primera transaccion
insert into pagos(codigocliente, formapago, idtransaccion, fechapago, cantidad)
values(11111, 'PAYPAL', 025, to_date('04/03/2013', 'dd/mm/yyyy'), 60);
--cuando el siguiente empleado llega se realiza la misma operacion miramos los costes y lo que ya ha pagado
select preciounidad*cantidad
from detallepedidos
where codigopedido=150;

select preciounidad*cantidad
from detallepedidos
where codigopedido=155;
--Y despues el total de pagos que se han efectuado
select cantidad
from pagos
where codigocliente=11111;-- nos aparece que ha realizado un pago de 60 por lo tanto no puede efectuarse el pago