--conectarse como sys
connect sys/alumno as sysdba

--creacion de usuarios
create user INFORMATICA identified by INFORMATICA default tablespace users;

create user RRHH identified by RRHH default tablespace users;

create user COMERCIAL identified by COMERCIAL default tablespace users;

create user CONTABILIDAD identified by CONTABILIDAD default tablespace users;

create user JARDINERIA identified by JARDINERIA default tablespace users;

--Asignar derechos al usuario informatica
grant connect, resource to INFORMATICA;

connect INFORMATICA/INFORMATICA

--Asigno derechos de conectabilidad a los dem�s usuarios
grant connect to RRHH;
connect RRHH/RRHH;

grant connect to COMERCIAL;
connect COMERCIAL/COMERCIAL;

grant connect to CONTABILIDAD;
connect CONTABILIDAD/CONTABILIDAD;

grant connect to JARDINERIA;
connect JARDINERIA/JARDINERIA;

commit;

--Privilegios de synonim
grant create synonym to INFORMATICA;
grant create synonym to RRHH;
grant create synonym to COMERCIAL;
grant create synonym to CONTABILIDAD;
grant create synonym to JARDINERIA;


