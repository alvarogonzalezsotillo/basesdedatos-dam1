--Se conecta a la base de datos
connect COMERCIAL/COMERCIAL;
set autocommit off;
--Synonyms tablas tablas Clientes, Pedidos, DetallePedidos, Productos, Empleados y Oficinas.

create synonym Productos for informatica.Productos;
create synonym DetallePedidos for informatica.DetallePedidos;
create synonym pedidos for informatica.pedidos;
create synonym Clientes for informatica.Clientes;
create synonym oficinas for informatica.oficinas;
create synonym empleados for informatica.empleados;

commit;
--COMERCIAL da de alta al nuevo cliente �PepeGardens�, en Madrid, sin representante.
insert into clientes(codigocliente, nombrecliente, telefono, fax, lineadireccion1, ciudad)
values(11111, 'PepeGardens', '9632145', '123-456','calle de pepe', 'madrid' ); 

--Despu�s hace una consulta encontrar a los empleados de mayor rango en Madrid (que no tienen un jefe en Madrid). 
select codigoempleado, nombre
from empleados
where codigojefe is null;

--Despu�s asigna el primero de esos empleados como representante de �PepeGardens�.
update clientes
set codigoempleadorepventas=1
where codigocliente=11111;

commit;

--consulta para ver cuantas ajedreas hay en stock
select cantidadenstock
from productos
where nombre='ajedreas'; --( hay 140 ajedreas)

--el primer comercial realiza lo siguiente
set transaction isolation level serializable;

insert into detallepedidos(codigopedido, codigoproducto, cantidad, preciounidad, numerolinea)
values(150, 'AR-001', 50, 1, 2);

insert into pedidos(codigopedido, fechapedido, fechaesperada, estado, codigocliente)
values(150, to_date('02/03/2013', 'dd/mm/yyyy'), to_date('04/03/2013', 'dd/mm/yyyy'), 'Pendiente', 11111 );

update productos 
set cantidadenstock=cantidadenstock-50
where nombre='Ajedrea' and cantidadenstcok>=50;


--el segundo comercial realida lo siguiente
select cantidadenstock
from productos
where nombre='ajedreas'; --puede ver la tabla ( hay 140 ajedreas)

update productos 
set cantidadenstock=cantidadenstock-140
where nombre='Ajedrea'and cantidadenstcok>=140; --esta bloqueado por el primer comercial y no nos muestra absolutamente nada 

--El primer comercial ha realizado ya la transaccion
commit;

--Una vez que el primer comercial hace el commit al segundo le aperece que no se ha creado el update aunq en un principio parecia que podria realizarlo. Se hace de nuevo un select nos aparece que el resultado es que solo quedan 90 Ajedreas.
select cantidadenstock
from productos
where nombre='ajedreas'; 

insert into pedidos(codigopedido, fechapedido, fechaesperada, estado, codigocliente)
values(151, to_date('02/03/2013', 'dd/mm/yyyy'), to_date('04/03/2013', 'dd/mm/yyyy'), 'Pendiente', 28 );

--Finalmente PepeGardens tambien hace un pedido de 10 palas y confirma tanto el anterior como este
insert into detallepedidos(codigopedido, codigoproducto, cantidad, preciounidad, numerolinea)
values(155, 'AR-024', 10, 1, 2);

insert into pedidos(codigopedido, fechapedido, fechaesperada, estado, codigocliente)
values(155, to_date('02/03/2013', 'dd/mm/yyyy'), to_date('04/03/2013', 'dd/mm/yyyy'), 'Pendiente', 11111 );


