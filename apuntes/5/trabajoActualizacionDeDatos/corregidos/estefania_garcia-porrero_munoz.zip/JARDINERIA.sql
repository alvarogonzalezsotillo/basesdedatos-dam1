
--Se conecta a la base de datos
connect JARDINERIA/JARDINERIA;
set autocommit off;
--Synonyms tablas tablas PRODUCTOS Y GAMASPRODUCTOS

create synonym Productos for informatica.Productos;
create synonym GAMASPRODUCTOS for informatica.GAMASPRODUCTOS;
