--Una vez conecctados a sql con el usuario informatica
connect INFORMATICA/INFORMATICA
set autocommit off;
--Subimos la base de datos
@jardineria.sql

commit;

--Damos el resto de permisos a los dem�s usuarios
--RRHH: Podr� modificar filas de las tablas Oficinas y Empleados
grant select, update, insert, delete
on oficinas
to RRHH;

grant select, update, insert, delete 
on empleados
to RRHH;

--COMERCIAL: Podr� modificar filas de las tablas Clientes, Pedidos y DetallePedidos.  Podr� modificar datos de la columna Productos.CantidadEnStock. Podr� ver la tabla Empleados y Oficinas.
grant select, update, insert, delete
on clientes 
to comercial;

grant select, update, insert, delete
on pedidos
to comercial;

grant select, update, insert, delete
on detallepedidos
to comercial;

grant select, update (CantidadEnStock)
on Productos
to comercial;

grant select
on empleados
to comercial;

grant select
on oficinas
to comercial;

commit;

--CONTABILIDAD: Podr� modificar filas de la tabla Pagos
grant select, update, insert, delete
on pagos
to contabilidad;

--JARDINERIA: Podr� modificar filas de las tablas Productos y GamasProductos
grant select, update, insert, delete
on productos
to jardineria;

grant select, update, insert, delete
on gamasproductos
to jardineria;

--derechos sobre la tabla cientes a RRHH
grant select, update, insert, delete
on cilentes
to RRHH;

commit;

