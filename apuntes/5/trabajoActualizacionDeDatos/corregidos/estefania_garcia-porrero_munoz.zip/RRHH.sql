--Se conecta a la base de datos
connect RRHH/RRHH

--Synonyms tablas tablas Oficinas y Empleados

create synonym oficinas for informatica.oficinas;
create synonym empleados for informatica.empleados;
create synonym clientes for informatica.clientes;

--RRHH ha creado a un nuevo empleado en Madrid (�Manolo Bombo�).
insert into empleados (codigoempleado, nombre, apellido1, extension, email, codigooficina)
values(123, 'Manolo', 'Bombo', 1234, 'manolin@gmail.com', 'MAD-ES');

-- RRHH est� desplazando al empleado de mayor rango de Madrid a Barcelona.bcn-es
--Para ello, est� asignando todos sus representados a �Manolo Bombo�, que depender� del jefe que depend�a antes el jefe de Madrid, y el resto de empleados de Madrid depender�n de Manolo Bombo
update clientes
set codigoempleadorepventas=123
where codigoempleadorepventas=1;

commit;