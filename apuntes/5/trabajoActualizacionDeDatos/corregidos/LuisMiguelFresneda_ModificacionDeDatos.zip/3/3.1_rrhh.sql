connect rrhh/rrhh

set autocommit off

set transaction isolation level serializable;

--inserto al nuevo empleado de Madrid, Manolo Bombo
insert into empleados
(codigoempleado,nombre,apellido1,extension,email,codigooficina)
values
(32,'Manolo','Bombo','3333','manolo@gardening.com','MAD-ES');

--para saber quien es el jefe del jefe de mayor rango en madrid:
select a.codigojefe
from empleados a
where a.codigooficina like 'MAD-ES' and
a.codigojefe not in (
  select e.codigoempleado
  from empleados e
  where e.codigooficina like 'MAD-ES');
--esto me da como resultado el codigojefe=3

--asigno este jefe a manolo bombo
update empleados set codigojefe=3 where codigoempleado=32;

--al resto de empleados de madrid les pongo como jefe a manolo bombo
update empleados set codigojefe=32
where codigooficina like 'MAD-ES' and
codigoempleado <> 32;
--esto me modifica a los empleados 7,8,9,10

--a los representados por el antiguo jefe de madrid les asigno el nuevo jefe
--de madrid manolo bombo
update clientes set CODIGOEMPLEADOREPVENTAS=32 where CODIGOEMPLEADOREPVENTAS=7;
--Aqu� me da 0 porque no se ha hecho commit con COMERCIAL.
--En este caso har�a un rollback

--Pero si COMERCIAL realizase el commit, RRHH har�a un commit, y entonces
--se modificar�a el representante de PepeGarden a Manolo Bombo

--Por lo tanto ya puedo desplazar al antiguo jefe de madrid a barcelona --ahora que ya no representa a ninguna empresa.
update empleados set codigooficina='BCN-ES' where codigoempleado=7;


commit;






