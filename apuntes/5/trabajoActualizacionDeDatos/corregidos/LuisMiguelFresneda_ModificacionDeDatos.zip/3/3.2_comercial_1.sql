--Este es el comercial que empieza primero con la transacci�n del ejercicio 3.2

connect comercial/comercial

set autocommit off

set transaction isolation level serializable;

--Este primer comercial realiza la transacci�n de restar 50 ajedreas

--Miro la cantidad de ajedreas que hay
select cantidadenstock from productos where nombre like 'Ajedrea';
--Me da 140 ajedreas

--realizo el pedido restanto 50 ajedreas
update productos set cantidadenstock=cantidadenstock-50 where nombre like 'Ajedrea';
--compruebo y se queda en 90 ajedreas

--Aqui el otro comercial empieza con su transacci�n, antes de que yo haga commit.

--Se hace commit porque ya se ha terminado:
commit;

