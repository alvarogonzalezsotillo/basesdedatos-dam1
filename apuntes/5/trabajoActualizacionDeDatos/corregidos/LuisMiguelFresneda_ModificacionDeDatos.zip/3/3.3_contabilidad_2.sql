--Este de contabilidad pretende realizar el pago de pepegarden sin que el otro haya realizado commit

connect contabilidad/contabilidad

set autocommit off

set transaction isolation level serializable;

--sabiendo que el codigocliente de PepeGarden es el 39, para saber la suma de todos sus pedidos realizo lo siguiente:
select sum(preciounidad*cantidad)
from detallepedidos
where codigopedido in (select codigopedido from pedidos where codigocliente=39);
--esto me da 190, es correcto

--para saber la suma de todos sus pagos:
select sum(cantidad) from pagos where codigocliente=39;

--no me devuelve nada, por tanto vamos a dar de alta el pago que quiere realizar por paypal:
insert into pagos values (39, 'PayPal', 'ak-std-000028', to_date('02-03-2013', 'dd-MM-YYYY'), 190);
--se queda a la espera

--al hacer el otro de contabilidad commit me da el siguiente error:
--unique constraint (INFORMATICA.SYS_C004363) violated
--porque intento poner el mismo codigotransaccion al ser correlativo

--por tanto
rollback;

--realizo de nuevo la consulta
select sum(cantidad) from pagos where codigocliente=39;
--y veo que tiene un pago de 190, por lo que no se realiza nada m�s.