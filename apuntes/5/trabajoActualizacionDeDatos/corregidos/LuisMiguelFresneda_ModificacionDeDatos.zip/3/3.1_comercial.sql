connect comercial/comercial

set autocommit off

set transaction isolation level serializable;


--inserto al cliente solicitado
insert into clientes
(codigocliente, nombrecliente, nombrecontacto, apellidocontacto, telefono, fax, lineadireccion1, ciudad, pais, codigopostal)
values (39, 'PepeGarden', 'Luis', 'Miguel', '655988655', '915554442', 'Cemento 2', 'Madrid', 'Espa�a', '28850');


--saco el codigo de empleados que son de madrid
select a.codigoempleado
from empleados a
where a.codigooficina like 'MAD-ES' and
--pero sus jefes no son de madrid
a.codigojefe not in (
  select e.codigoempleado
  from empleados e
  where e.codigooficina like 'MAD-ES');
--esto me da como resultado el codigoempleado=7


--asigno ese representante a pepegarden
update clientes set CODIGOEMPLEADOREPVENTAS=7 where codigocliente=39;

--En este punto es d�nde empieza a modificar RRHH...

--hago commit porque he terminado
commit;