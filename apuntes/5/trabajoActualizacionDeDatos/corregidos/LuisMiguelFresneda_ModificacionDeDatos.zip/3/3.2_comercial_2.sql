--Este es el comercial que empieza segundo con la transacci�n del ejercicio 3.2

connect comercial/comercial

set autocommit off

set transaction isolation level serializable;


--este segundo comercial realizar� la misma operaci�n miestras la esta realizando el otro, es decir, el otro aun no ha hecho commit

--Miro la cantidad de ajedreas que hay
select cantidadenstock from productos where nombre like 'Ajedrea';
--Me da 140 ajedreas

--realizo el pedido restando 140 a las ajedreas
update productos set cantidadenstock=cantidadenstock-140 where nombre like 'Ajedrea';
--se queda a la espera

--Una vez que el otro comercial ha hecho commit da el siguiente error:
--ORA-08177: can't serialize access for this transaction

--Por lo tanto: 
rollback;