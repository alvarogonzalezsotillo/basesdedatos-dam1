--Veo que para este ejercicio necesito dar de alta los pedidos desde comercial:

connect comercial/comercial
set autocommit off
set transaction isolation level serializable;
--inserto los pedidos
insert into pedidos (codigopedido, fechapedido, fechaesperada, estado, codigocliente)
values (129, to_date('02-03-2013', 'dd-MM-YYYY'), to_date('02-04-2013', 'dd-MM-YYYY'), 'Pendiente', 39);

insert into pedidos (codigopedido, fechapedido, fechaesperada, estado, codigocliente)
values (130, to_date('02-03-2013', 'dd-MM-YYYY'), to_date('02-04-2013', 'dd-MM-YYYY'), 'Pendiente', 39);

--creo los detalles de los pedidos
insert into detallepedidos values(129, 'AR-001', 50, 1, 1);
insert into detallepedidos values(130, '21636', 10, 14, 2);

commit;
disconnect



--ahora ya comienzo con contabilidad
connect contabilidad/contabilidad

set autocommit off

set transaction isolation level serializable;

--sabiendo que el codigocliente de PepeGarden es el 39, para saber la suma de todos sus pedidos realizo lo siguiente:
select sum(preciounidad*cantidad)
from detallepedidos
where codigopedido in (select codigopedido from pedidos where codigocliente=39);
--esto me da 190, es correcto

--para saber la suma de todos sus pagos:
select sum(cantidad) from pagos where codigocliente=39;

--no me devuelve nada, por tanto vamos a dar de alta el pago que quiere realizar por paypal:
insert into pagos values (39, 'PayPal', 'ak-std-000028', to_date('02-03-2013', 'dd-MM-YYYY'), 190);

--ahora la siguiente consulta me da 190
select sum(cantidad) from pagos where codigocliente=39;

--En este punto otro de contabilidad intenta hacer la misma operaci�n sin yo haber hecho commit

--como ya he terminado:
commit;


