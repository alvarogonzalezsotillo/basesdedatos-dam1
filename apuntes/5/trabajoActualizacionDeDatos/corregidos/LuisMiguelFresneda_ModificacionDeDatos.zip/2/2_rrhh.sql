connect RRHH/RRHH

create synonym oficinas for informatica.oficinas;
create synonym empleados for informatica.empleados;
create synonym clientes for informatica.clientes;

