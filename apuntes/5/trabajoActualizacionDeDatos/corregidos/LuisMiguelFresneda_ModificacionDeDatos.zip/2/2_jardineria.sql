connect JARDINERIA/JARDINERIA

create synonym gamasproductos for informatica.gamasproductos;
create synonym productos for informatica.productos;
