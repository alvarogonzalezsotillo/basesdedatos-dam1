connect CONTABILIDAD/CONTABILIDAD

create synonym pagos for informatica.pagos;
create synonym pedidos for informatica.pedidos;
create synonym detallepedidos for informatica.detallepedidos;
