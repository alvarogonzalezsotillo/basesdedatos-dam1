connect COMERCIAL/COMERCIAL

create synonym oficinas for informatica.oficinas;
create synonym empleados for informatica.empleados;
create synonym clientes for informatica.clientes;
create synonym pedidos for informatica.pedidos;
create synonym productos for informatica.productos;
create synonym detallepedidos for informatica.detallepedidos;
