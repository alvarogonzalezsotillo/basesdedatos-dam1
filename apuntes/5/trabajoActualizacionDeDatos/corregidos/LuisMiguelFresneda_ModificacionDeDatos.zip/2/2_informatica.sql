connect informatica/informatica

@jardineria_oracle.sql


grant select on oficinas to RRHH;
grant update on oficinas to RRHH;
grant select on empleados to RRHH;
grant update on empleados to RRHH;
grant insert on empleados to RRHH;
--veo que rrhh necesita ver y modificar la tabla clientes
grant select on clientes to RRHH;
grant update on clientes to RRHH;

--veo que comercial va a necesitar insertar filas en pedidos y detallepedidos
grant select on clientes to COMERCIAL;
grant update on clientes to COMERCIAL;
grant insert on clientes to COMERCIAL;
grant select on pedidos to COMERCIAL;
grant update on pedidos to COMERCIAL;
grant insert on pedidos to COMERCIAL;
grant select on detallepedidos to COMERCIAL;
grant update on detallepedidos to COMERCIAL;
grant insert on detallepedidos to COMERCIAL;
grant select on productos to COMERCIAL;
grant update(cantidadEnStock) on productos to COMERCIAL;
grant select on empleados to COMERCIAL;
grant select on oficinas to COMERCIAL;

grant select on pagos to CONTABILIDAD;
grant update on pagos to CONTABILIDAD;
grant insert on pagos to CONTABILIDAD;
--veo que contabilidad va a necesitar tambi�n ver las tablas pedidos y detallepedidos
grant select on pedidos to CONTABILIDAD;
grant select on detallepedidos to CONTABILIDAD;

grant select on productos to JARDINERIA;
grant update on productos to JARDINERIA;
grant select on gamasproductos to JARDINERIA;
grant update on gamasproductos to JARDINERIA;