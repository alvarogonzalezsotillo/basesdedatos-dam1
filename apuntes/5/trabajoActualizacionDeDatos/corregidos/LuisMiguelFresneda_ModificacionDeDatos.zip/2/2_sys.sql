connect sys/alumno as sysdba

create user RRHH identified by RRHH default tablespace users;
create user COMERCIAL identified by COMERCIAL default tablespace users;
create user CONTABILIDAD identified by CONTABILIDAD default tablespace users;
create user JARDINERIA identified by JARDINERIA default tablespace users;
create user INFORMATICA identified by INFORMATICA default tablespace users;

grant connect to INFORMATICA;
grant resource to INFORMATICA;
grant connect to RRHH, COMERCIAL, CONTABILIDAD, JARDINERIA;
grant create synonym to RRHH, COMERCIAL, CONTABILIDAD, JARDINERIA;
