-- Generado por Oracle SQL Developer Data Modeler 3.1.2.704
--   en:        2012-11-21 17:03:44 CET
--   sitio:      Oracle Database 11g
--   tipo:      Oracle Database 11g



CREATE TABLE Cliente 
    ( 
     Usuario VARCHAR2 (50)  NOT NULL , 
     Nombre VARCHAR2 (50) , 
     Apellidos VARCHAR2 (50) , 
     "e-mail" VARCHAR2 (50) , 
     Cod_pedido INTEGER 
    ) 
;


CREATE UNIQUE INDEX Cliente__IDX ON Cliente 
    ( 
     Cod_pedido ASC 
    ) 
;

ALTER TABLE Cliente 
    ADD CONSTRAINT "Cliente PK" PRIMARY KEY ( Usuario ) ;



CREATE TABLE Coleccion 
    ( 
     Cod_Coleccion INTEGER  NOT NULL , 
     cod_mueble INTEGER 
    ) 
;


CREATE UNIQUE INDEX Coleccion__IDX ON Coleccion 
    ( 
     cod_mueble ASC 
    ) 
;

ALTER TABLE Coleccion 
    ADD CONSTRAINT "Coleccion PK" PRIMARY KEY ( Cod_Coleccion ) ;



CREATE TABLE Coleccion_Tiene_color 
    ( 
     Coleccion_Cod_Coleccion INTEGER  NOT NULL , 
     Color_Cod_Color INTEGER  NOT NULL 
    ) 
;



ALTER TABLE Coleccion_Tiene_color 
    ADD CONSTRAINT Tienev2__IDX PRIMARY KEY ( Coleccion_Cod_Coleccion, Color_Cod_Color ) ;



CREATE TABLE Coleccion_tiene_cristal 
    ( 
     Coleccion_Cod_Coleccion INTEGER  NOT NULL , 
     Cristal_Cod_Cristal INTEGER  NOT NULL 
    ) 
;



ALTER TABLE Coleccion_tiene_cristal 
    ADD CONSTRAINT Tienev1__IDX PRIMARY KEY ( Coleccion_Cod_Coleccion, Cristal_Cod_Cristal ) ;



CREATE TABLE Coleccion_tiene_terminacion 
    ( 
     Coleccion_Cod_Coleccion INTEGER  NOT NULL , 
     Terminacion_Cod_Terminacion INTEGER  NOT NULL 
    ) 
;



ALTER TABLE Coleccion_tiene_terminacion 
    ADD CONSTRAINT Tiene__IDX PRIMARY KEY ( Coleccion_Cod_Coleccion, Terminacion_Cod_Terminacion ) ;



CREATE TABLE Color 
    ( 
     Cod_Color INTEGER  NOT NULL 
    ) 
;



ALTER TABLE Color 
    ADD CONSTRAINT "Color PK" PRIMARY KEY ( Cod_Color ) ;



CREATE TABLE Cristal 
    ( 
     Cod_Cristal INTEGER  NOT NULL , 
     Tipo VARCHAR2 (50) 
    ) 
;



ALTER TABLE Cristal 
    ADD CONSTRAINT "Cristal PK" PRIMARY KEY ( Cod_Cristal ) ;



CREATE TABLE LineaPedido 
    ( 
     Cantidad INTEGER , 
     cod_mueble INTEGER , 
     Cod_pedido INTEGER , 
     Cod_Terminacion INTEGER , 
     Cod_Color INTEGER , 
     Cod_Cristal INTEGER 
    ) 
;




CREATE TABLE Muebele_es_de_Temporada 
    ( 
     Mueble_cod_mueble INTEGER  NOT NULL , 
     Temporada_Cod_Temporada INTEGER  NOT NULL 
    ) 
;



ALTER TABLE Muebele_es_de_Temporada 
    ADD CONSTRAINT "es de__IDX" PRIMARY KEY ( Mueble_cod_mueble, Temporada_Cod_Temporada ) ;



CREATE TABLE Mueble 
    ( 
     cod_mueble INTEGER  NOT NULL , 
     Tipo VARCHAR2 (50) , 
     Ambiente VARCHAR2 (50) , 
     Precio INTEGER , 
     Dimension VARCHAR2 (50) , 
     Cod_pedido INTEGER , 
     Cod_Coleccion INTEGER 
    ) 
;


CREATE UNIQUE INDEX Mueble__IDX ON Mueble 
    ( 
     Cod_pedido ASC 
    ) 
;

ALTER TABLE Mueble 
    ADD CONSTRAINT "Mueble PK" PRIMARY KEY ( cod_mueble ) ;



CREATE TABLE Pedido 
    ( 
     Cod_pedido INTEGER  NOT NULL , 
     cod_mueble INTEGER , 
     Usuario VARCHAR2 (50) 
    ) 
;


CREATE UNIQUE INDEX Pedido__IDX ON Pedido 
    ( 
     cod_mueble ASC 
    ) 
;

ALTER TABLE Pedido 
    ADD CONSTRAINT "Pedido PK" PRIMARY KEY ( Cod_pedido ) ;



CREATE TABLE Temporada 
    ( 
     Cod_Temporada INTEGER  NOT NULL , 
     Nombre VARCHAR2 (50) , 
     Año INTEGER 
    ) 
;



ALTER TABLE Temporada 
    ADD CONSTRAINT "Temporada PK" PRIMARY KEY ( Cod_Temporada ) ;



CREATE TABLE Terminacion 
    ( 
     Cod_Terminacion INTEGER  NOT NULL 
    ) 
;



ALTER TABLE Terminacion 
    ADD CONSTRAINT "Terminacion PK" PRIMARY KEY ( Cod_Terminacion ) ;




ALTER TABLE Coleccion_tiene_cristal 
    ADD CONSTRAINT FK_ASS_10 FOREIGN KEY 
    ( 
     Cristal_Cod_Cristal
    ) 
    REFERENCES Cristal 
    ( 
     Cod_Cristal
    ) 
    ON DELETE CASCADE 
;


ALTER TABLE Coleccion_Tiene_color 
    ADD CONSTRAINT FK_ASS_11 FOREIGN KEY 
    ( 
     Coleccion_Cod_Coleccion
    ) 
    REFERENCES Coleccion 
    ( 
     Cod_Coleccion
    ) 
    ON DELETE CASCADE 
;


ALTER TABLE Coleccion_Tiene_color 
    ADD CONSTRAINT FK_ASS_12 FOREIGN KEY 
    ( 
     Color_Cod_Color
    ) 
    REFERENCES Color 
    ( 
     Cod_Color
    ) 
    ON DELETE CASCADE 
;


ALTER TABLE Muebele_es_de_Temporada 
    ADD CONSTRAINT FK_ASS_2 FOREIGN KEY 
    ( 
     Mueble_cod_mueble
    ) 
    REFERENCES Mueble 
    ( 
     cod_mueble
    ) 
    ON DELETE CASCADE 
;


ALTER TABLE Muebele_es_de_Temporada 
    ADD CONSTRAINT FK_ASS_3 FOREIGN KEY 
    ( 
     Temporada_Cod_Temporada
    ) 
    REFERENCES Temporada 
    ( 
     Cod_Temporada
    ) 
    ON DELETE CASCADE 
;


ALTER TABLE Coleccion_tiene_terminacion 
    ADD CONSTRAINT FK_ASS_7 FOREIGN KEY 
    ( 
     Coleccion_Cod_Coleccion
    ) 
    REFERENCES Coleccion 
    ( 
     Cod_Coleccion
    ) 
    ON DELETE CASCADE 
;


ALTER TABLE Coleccion_tiene_terminacion 
    ADD CONSTRAINT FK_ASS_8 FOREIGN KEY 
    ( 
     Terminacion_Cod_Terminacion
    ) 
    REFERENCES Terminacion 
    ( 
     Cod_Terminacion
    ) 
    ON DELETE CASCADE 
;


ALTER TABLE Coleccion_tiene_cristal 
    ADD CONSTRAINT FK_ASS_9 FOREIGN KEY 
    ( 
     Coleccion_Cod_Coleccion
    ) 
    REFERENCES Coleccion 
    ( 
     Cod_Coleccion
    ) 
    ON DELETE CASCADE 
;


ALTER TABLE LineaPedido 
    ADD CONSTRAINT LineaPedido_tiene_Color FOREIGN KEY 
    ( 
     Cod_Color
    ) 
    REFERENCES Color 
    ( 
     Cod_Color
    ) 
;


ALTER TABLE LineaPedido 
    ADD CONSTRAINT LineaPedido_tiene_Cristal FOREIGN KEY 
    ( 
     Cod_Cristal
    ) 
    REFERENCES Cristal 
    ( 
     Cod_Cristal
    ) 
;


ALTER TABLE LineaPedido 
    ADD CONSTRAINT LineaPedido_tiene_Terminacion FOREIGN KEY 
    ( 
     Cod_Terminacion
    ) 
    REFERENCES Terminacion 
    ( 
     Cod_Terminacion
    ) 
;


ALTER TABLE Mueble 
    ADD CONSTRAINT "Pertenece a" FOREIGN KEY 
    ( 
     Cod_Coleccion
    ) 
    REFERENCES Coleccion 
    ( 
     Cod_Coleccion
    ) 
;


ALTER TABLE Coleccion 
    ADD CONSTRAINT "Pertenece a" FOREIGN KEY 
    ( 
     cod_mueble
    ) 
    REFERENCES Mueble 
    ( 
     cod_mueble
    ) 
;


ALTER TABLE Pedido 
    ADD CONSTRAINT Realiza FOREIGN KEY 
    ( 
     Usuario
    ) 
    REFERENCES Cliente 
    ( 
     Usuario
    ) 
;


ALTER TABLE Cliente 
    ADD CONSTRAINT Realiza FOREIGN KEY 
    ( 
     Cod_pedido
    ) 
    REFERENCES Pedido 
    ( 
     Cod_pedido
    ) 
;


ALTER TABLE LineaPedido 
    ADD CONSTRAINT Tiene FOREIGN KEY 
    ( 
     cod_mueble
    ) 
    REFERENCES Mueble 
    ( 
     cod_mueble
    ) 
;


ALTER TABLE LineaPedido 
    ADD CONSTRAINT Tienev2 FOREIGN KEY 
    ( 
     Cod_pedido
    ) 
    REFERENCES Pedido 
    ( 
     Cod_pedido
    ) 
;


ALTER TABLE Pedido 
    ADD CONSTRAINT "se compone de" FOREIGN KEY 
    ( 
     cod_mueble
    ) 
    REFERENCES Mueble 
    ( 
     cod_mueble
    ) 
;


ALTER TABLE Mueble 
    ADD CONSTRAINT "se compone de" FOREIGN KEY 
    ( 
     Cod_pedido
    ) 
    REFERENCES Pedido 
    ( 
     Cod_pedido
    ) 
;



-- Informe de Resumen de Oracle SQL Developer Data Modeler: 
-- 
-- CREATE TABLE                            13
-- CREATE INDEX                             4
-- ALTER TABLE                             31
-- CREATE VIEW                              0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           0
-- ALTER TRIGGER                            0
-- CREATE STRUCTURED TYPE                   0
-- CREATE COLLECTION TYPE                   0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          0
-- CREATE MATERIALIZED VIEW                 0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- ERRORS                                   0
-- WARNINGS                                 0
